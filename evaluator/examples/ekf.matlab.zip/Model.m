% SOC Estimation Example V2
function [SOC_Pred, z] = Model(X,z)
%% load parameters
I = -X(1);
V = X(2);
if nargin <2 % Only for initialization
    % Load ECM parameters and OCV_SOC curves
    data = load('ECM_parameters');
    ECM = data.ECM;
    data = load('OCV_table.mat');
    OCV_table = data.OCV_table;
    SOC_range = data.SOC_range;
    data = load('EKF_parameters.mat');
    EKF = data.EKF;
    % Select correct temperature
    if X(3) > 30
        z.Param = ECM.T40;
        z.EKF = EKF.T40;
        T = 6;
    elseif X(3) > 17.5
        z.Param = ECM.T25;
        z.EKF = EKF.T25;
        T = 5;
    elseif X(3) > 5
        z.Param = ECM.T10;
        z.EKF = EKF.T10;
        T = 4;
    elseif X(3) > -5
        z.Param = ECM.T0;
        z.EKF = EKF.T0;
        T = 3;
    elseif X(3) > -15
        z.Param = ECM.Tn10;
        z.EKF = EKF.Tn10;
        T = 2;
    else
        z.Param = ECM.Tn20;
        z.EKF = EKF.Tn20;
        T = 1;
    end
    z.OCV_SOC = OCV_table(T,:); % select corresponding curve for Temp
    z.SOC_range = SOC_range;
    init_SOC = min(1,max(0,interp1(z.OCV_SOC,SOC_range,X(1,2),'linear','extrap')));
    
    % Load relevant parameters
    z.C0 = 4.68; % capacity
    z.R0 = interp1(z.Param.SOC, z.Param.R0, init_SOC,'linear','extrap');
    z.R1 = interp1(z.Param.SOC, z.Param.R1, init_SOC,'linear','extrap');
    z.R2 = interp1(z.Param.SOC, z.Param.R2, init_SOC,'linear','extrap');
    z.R3 = interp1(z.Param.SOC, z.Param.R3, init_SOC,'linear','extrap');
    z.C1 = interp1(z.Param.SOC, z.Param.T1, init_SOC,'linear','extrap')/z.R1;
    z.C2 = interp1(z.Param.SOC, z.Param.T2, init_SOC,'linear','extrap')/z.R2;
    z.C3 = interp1(z.Param.SOC, z.Param.T3, init_SOC,'linear','extrap')/z.R3;
    z.Param.SOC_now = init_SOC;
    P = diag([0.05,0.05,0.05,0.001]);    % initial state covariance
    x = [0 0 0 init_SOC];            % initial state
else
    P = z.P;                % initial state covariance (previously calculated)
    x = z.x;                % initial state (previously calculated)
end

% Covariance matrices 
R = z.EKF.R;
Q = z.EKF.Q;

% Nonlinear state function
f = @(x) [exp(-1/(z.C1*z.R1))*x(1)+((1-exp(-1/(z.R1*z.C1)))*z.R1)*I;  % First order RC
          exp(-1/(z.C2*z.R2))*x(2)+((1-exp(-1/(z.R2*z.C2)))*z.R2)*I;  % Second order RC
          exp(-1/(z.C3*z.R3))*x(3)+((1-exp(-1/(z.R3*z.C3)))*z.R3)*I;  % Second order RC
          x(4)-1/(3600*z.C0)*I];                                      % SOC

% Nonlinear output function 
h = @(x) interp1(z.SOC_range, z.OCV_SOC, x(4), 'linear', 'extrap') - x(1) - x(2) - x(3);

% Jacobian of f
F = [exp(-1/(z.C1*z.R1)), 0, 0, 0;
    0, exp(-1/(z.C2*z.R2)), 0, 0;
    0, 0, exp(-1/(z.C3*z.R3)), 0;
    0, 0, 0, 0;]; 
% Jacobian of h

% Calculate the gradient of the OCV_SOC curve
n = length(z.OCV_SOC);
dOCV_dSOC = zeros(size(z.OCV_SOC));
for i = 2:n-1
    dOCV_dSOC(i) = (z.OCV_SOC(i+1) - z.OCV_SOC(i-1)) / (z.SOC_range(i+1) - z.SOC_range(i-1));
end
dOCV_dSOC(1) = (z.OCV_SOC(2) - z.OCV_SOC(1)) / (z.SOC_range(2) - z.SOC_range(1));
dOCV_dSOC(n) = (z.OCV_SOC(n) - z.OCV_SOC(n-1)) / (z.SOC_range(n) - z.SOC_range(n-1));

H = [-1, -1, -1, interp1(z.SOC_range, dOCV_dSOC, x(4), 'linear', 'extrap')];

% Prediction step
x_hat = f(x);           % State prediction
P = F*P*F' + Q;         % Predicted Covariance

y_hat = h(x_hat);       % Output prediction
error = V-y_hat;        % error
% 
S = H*P*H' + R;         % Innovation covariance
K = P*H'*S^(-1);        % Kalman gain

% Update step
x_pred = x_hat + K*(error);
P = (eye(4) - K*H)*P;

% Use SOC_OCV table to find SOC corresponding to OCV
SOC_Pred = x_pred(4); 
z.P = P;
z.x = x_pred;

if abs(SOC_Pred - z.Param.SOC_now ) > 0.02
    z.R0 = interp1(z.Param.SOC, z.Param.R0, SOC_Pred,'linear','extrap');
    z.R1 = interp1(z.Param.SOC, z.Param.R1, SOC_Pred,'linear','extrap');
    z.R2 = interp1(z.Param.SOC, z.Param.R2, SOC_Pred,'linear','extrap');
    z.R3 = interp1(z.Param.SOC, z.Param.R3, SOC_Pred,'linear','extrap');
    z.C1 = interp1(z.Param.SOC, z.Param.T1, SOC_Pred,'linear','extrap')/z.R1;
    z.C2 = interp1(z.Param.SOC, z.Param.T2, SOC_Pred,'linear','extrap')/z.R2;
    z.C3 = interp1(z.Param.SOC, z.Param.T3, SOC_Pred,'linear','extrap')/z.R3;
    z.Param.SOC_now = SOC_Pred;
end


end