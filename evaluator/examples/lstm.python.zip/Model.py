# SOC Estimation Example — LSTM (10 units) stepped one sample at a time (Python)
# Weights exported from the trained MATLAB network into weights.npz
import numpy as np
from pathlib import Path

# dict(): materialise the arrays once — indexing an NpzFile re-reads the archive on every access
W = dict(np.load(Path(__file__).resolve().parent / "weights.npz"))
MAX = np.array([15.0, 4.5, 51.0])              # normalisation ranges used in training: [I, V, T]
MIN = np.array([-19.0, 2.5, -27.0])


def _sigmoid(v):
    return 1 / (1 + np.exp(-v))


def Model(X, z=None):
    x = np.array([(X[1] - MIN[1]) / (MAX[1] - MIN[1]),   # voltage
                  (X[0] - MIN[0]) / (MAX[0] - MIN[0]),   # current
                  (X[2] - MIN[2]) / (MAX[2] - MIN[2])])  # temperature
    if z is None:
        z = {"h": np.zeros(10), "c": np.zeros(10)}

    gates = W["W"] @ x + W["U"] @ z["h"] + W["b"]        # gate order: input, forget, cell, output
    i, f, g, o = np.split(gates, 4)
    c = _sigmoid(f) * z["c"] + _sigmoid(i) * np.tanh(g)
    h = _sigmoid(o) * np.tanh(c)
    y = float(np.clip(W["fc_w"] @ h + float(W["fc_b"]), 0, 1))   # clipped ReLU on the output
    return y, {"h": h, "c": c}
