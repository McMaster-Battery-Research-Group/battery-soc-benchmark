# SOC Estimation Example — feedforward NN 3 -> 23 -> 18 -> 1, ReLU (Python)
# Weights exported from the trained MATLAB network into weights.npz
import numpy as np
from pathlib import Path

W = np.load(Path(__file__).resolve().parent / "weights.npz")
WINDOW = 300                                   # inputs are averaged over the last 300 samples


def Model(X, z=None):
    x = np.asarray(X, float)
    if z is None:
        z = np.repeat(x[None, :], WINDOW, axis=0)  # seed the window with the first sample
    else:
        z = np.vstack([z[1:], x])                  # slide the window
    xin = z.mean(axis=0)

    xp = (xin - W["x_offset"]) * W["x_gain"] - 1   # mapminmax to [-1, 1]
    a1 = np.maximum(0, W["W1"] @ xp + W["b1"])     # ReLU
    a2 = np.maximum(0, W["W2"] @ a1 + W["b2"])
    a3 = W["W3"] @ a2 + float(W["b3"])
    y = (a3 + 1) / float(W["y_gain"]) + float(W["y_offset"])   # mapminmax reverse
    return float(y), z
