# SOC Estimation Example — Extended Kalman Filter, third-order Thevenin ECM (Python)
import numpy as np
from scipy.io import loadmat
from pathlib import Path

HERE = Path(__file__).resolve().parent


def _interp(x, xp, fp):
    """linear interpolation with extrapolation (MATLAB interp1 'linear','extrap')"""
    xp, fp = np.asarray(xp, float), np.asarray(fp, float)
    if x <= xp[0]:
        return float(fp[0] + (x - xp[0]) * (fp[1] - fp[0]) / (xp[1] - xp[0]))
    if x >= xp[-1]:
        return float(fp[-1] + (x - xp[-1]) * (fp[-1] - fp[-2]) / (xp[-1] - xp[-2]))
    return float(np.interp(x, xp, fp))


def _init(X):
    ecm = loadmat(HERE / "ECM_parameters.mat", squeeze_me=True, struct_as_record=False)["ECM"]
    ocv = loadmat(HERE / "OCV_table.mat", squeeze_me=True)
    ekf = loadmat(HERE / "EKF_parameters.mat", squeeze_me=True, struct_as_record=False)["EKF"]
    T = X[2]                                     # pick the parameter set for the measured temperature
    key = "T40" if T > 30 else "T25" if T > 17.5 else "T10" if T > 5 else "T0" if T > -5 else "Tn10" if T > -15 else "Tn20"
    row = ["Tn20", "Tn10", "T0", "T10", "T25", "T40"].index(key)
    z = {"P": getattr(ecm, key), "E": getattr(ekf, key), "ocv": ocv["OCV_table"][row, :], "soc_range": ocv["SOC_range"], "C0": 4.68}
    init_soc = min(1.0, max(0.0, _interp(X[1], z["ocv"], z["soc_range"])))
    _params(z, init_soc)
    z["Pcov"] = np.diag([0.05, 0.05, 0.05, 0.001])           # initial state covariance
    z["x"] = np.array([0.0, 0.0, 0.0, init_soc])              # [V_RC1 V_RC2 V_RC3 SOC]
    return z


def _params(z, soc):
    P = z["P"]
    z["R0"] = _interp(soc, P.SOC, P.R0)
    z["R"] = [_interp(soc, P.SOC, getattr(P, f"R{i}")) for i in (1, 2, 3)]
    z["C"] = [_interp(soc, P.SOC, getattr(P, f"T{i}")) / z["R"][i - 1] for i in (1, 2, 3)]
    z["soc_now"] = soc


def Model(X, z=None):
    if z is None:
        z = _init(X)
    I, V = -float(X[0]), float(X[1])             # positive = discharge inside the model
    R, C = z["R"], z["C"]
    a = [np.exp(-1 / (C[i] * R[i])) for i in range(3)]
    x, Pcov = z["x"], z["Pcov"]
    Q, Rn = np.asarray(z["E"].Q, float), float(np.asarray(z["E"].R, float))

    # ---- predict: three RC branches + Coulomb counting for SOC
    x_hat = np.array([a[i] * x[i] + (1 - a[i]) * R[i] * I for i in range(3)] + [x[3] - I / (3600 * z["C0"])])
    F = np.diag(a + [0.0])
    Pcov = F @ Pcov @ F.T + Q
    ocv, sr = z["ocv"], z["soc_range"]
    y_hat = _interp(x_hat[3], sr, ocv) - x_hat[0] - x_hat[1] - x_hat[2]
    docv = np.gradient(ocv, sr)                   # dOCV/dSOC
    H = np.array([-1.0, -1.0, -1.0, _interp(x_hat[3], sr, docv)])

    # ---- update
    S = H @ Pcov @ H + Rn
    K = Pcov @ H / S
    x = x_hat + K * (V - y_hat)
    Pcov = (np.eye(4) - np.outer(K, H)) @ Pcov
    z["x"], z["Pcov"] = x, Pcov

    soc = float(x[3])
    if abs(soc - z["soc_now"]) > 0.02:            # re-interpolate ECM parameters
        _params(z, soc)
    return soc, z
