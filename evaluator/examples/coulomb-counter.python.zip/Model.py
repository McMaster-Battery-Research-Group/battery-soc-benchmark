# SOC Estimation Example — online Coulomb counter (Python)
import numpy as np

CAPACITY_AH = 4.6                      # nominal capacity of the cell


def Model(X, z=None):
    """X = [current (A, negative = discharge), voltage (V), temperature (C)]
    Returns (SOC estimate in 0..1, memory z for the next call)."""
    current = float(X[0])
    if z is None:                      # first sample: assume fully charged
        soc = 1.0
    else:
        soc = float(z) + current * (1 / 3600) / CAPACITY_AH   # integrate current
    return soc, soc                    # memory z = previous SOC
